# main.py
# Entrypoint do Lotofácil Pro V11
# Compatível com: gerar_jogos() -> Tuple[List[Tuple[Concurso, float, int]], Dict[str, Any]]

import sys
from typing import Any, Dict, List, Tuple

from core.domain.models import Concurso
from core.engine.probabilistic_engine import ProbabilisticEngine
from core.infrastructure.database.database import carregar_concursos

# ---------------------------------------------------------------------------
# Constantes — Janela de Ouro
# ---------------------------------------------------------------------------
JANELA_OURO_MAX_FALTANTES: int = 4
JANELA_OURO_MIN_SCORE: float = 1.18

# ---------------------------------------------------------------------------
# Constantes — configuração padrão do motor
# ---------------------------------------------------------------------------
QUANTIDADE_JOGOS: int = 5


# ===========================================================================
# Camada de apresentação
# ===========================================================================

def _linha(char: str = "─", largura: int = 64) -> str:
    return char * largura


def _formatar_dezenas(dezenas: Tuple[int, ...]) -> str:
    """Exibe as dezenas ordenadas, formatadas com zero à esquerda."""
    return "  ".join(f"{d:02d}" for d in sorted(dezenas))


def _exibir_cabecalho() -> None:
    print(_linha("═"))
    print("       LOTOFÁCIL PRO V11  —  ANÁLISE PROBABILÍSTICA")
    print(_linha("═"))


def _exibir_info_ciclo(ciclo_info: Dict[str, Any]) -> None:
    """
    Exibe as métricas do ciclo retornadas pelo motor.
    Todas as chaves são opcionais — usa .get() com fallback seguro.
    """
    total_concursos: int   = ciclo_info.get("total_concursos", 0)
    ciclo_atual: int       = ciclo_info.get("ciclo_atual", 0)
    dezenas_faltantes: int = ciclo_info.get("dezenas_faltantes", 99)
    score_medio: float     = ciclo_info.get("score_medio", 0.0)

    print(f"  {'Total de concursos analisados':<32}: {total_concursos}")
    print(f"  {'Ciclo atual':<32}: {ciclo_atual}")
    print(f"  {'Dezenas faltantes no ciclo':<32}: {dezenas_faltantes}")
    print(f"  {'Score médio do lote':<32}: {score_medio:.4f}")
    print()

    if dezenas_faltantes <= JANELA_OURO_MAX_FALTANTES:
        print("  ╔══════════════════════════════════════════╗")
        print("  ║  ⚡  JANELA DE OURO ATIVA               ║")
        print(f"  ║     Faltam apenas {dezenas_faltantes} dezena(s) no ciclo!  ║")
        print("  ╚══════════════════════════════════════════╝")
        print()


def _exibir_jogo(
    idx: int,
    jogo: Concurso,
    score: float,
    repeticoes: int,
    janela_ativa: bool,
) -> None:
    """
    Exibe um único jogo gerado pelo motor.

    Args:
        idx:          Número sequencial do jogo no lote (1-based).
        jogo:         Objeto Concurso gerado — acesso via jogo.dezenas.
        score:        Score probabilístico calculado pelo motor.
        repeticoes:   Número de repetições/ocorrências históricas.
        janela_ativa: True se o jogo individual cumpre o critério da Janela de Ouro.
    """
    sufixo: str = "  🏆 [JANELA DE OURO]" if janela_ativa else ""
    print(f"  Jogo #{idx:02d}{sufixo}")
    print(f"    Dezenas    : {_formatar_dezenas(jogo.dezenas)}")
    print(f"    Score      : {score:.4f}")
    print(f"    Repetições : {repeticoes}")
    print()


def _exibir_dashboard(
    jogos: List[Tuple[Concurso, float, int]],
    ciclo_info: Dict[str, Any],
) -> None:
    """
    Pipeline de apresentação completo.

    Desempacota cada elemento de `jogos` como (Concurso, float, int),
    eliminando qualquer risco de AttributeError por acesso incorreto.
    """
    dezenas_faltantes: int = ciclo_info.get("dezenas_faltantes", 99)
    janela_ouro_ciclo: bool = dezenas_faltantes <= JANELA_OURO_MAX_FALTANTES

    _exibir_cabecalho()
    _exibir_info_ciclo(ciclo_info)

    print(_linha("─"))
    print(f"  {len(jogos)} JOGO(S) GERADO(S) PELO MOTOR PROBABILÍSTICO")
    print(_linha("─"))
    print()

    for idx, resultado in enumerate(jogos, start=1):
        # ─── Desempacotamento explícito e tipado ───────────────────────────
        # `resultado` é Tuple[Concurso, float, int] — nunca um dict ou tupla bruta
        jogo: Concurso       = resultado[0]
        score: float         = resultado[1]
        repeticoes: int      = resultado[2]
        # ──────────────────────────────────────────────────────────────────

        # Janela de Ouro individual: ciclo + score do jogo
        janela_jogo: bool = janela_ouro_ciclo and score >= JANELA_OURO_MIN_SCORE

        _exibir_jogo(idx, jogo, score, repeticoes, janela_jogo)

    print(_linha("═"))


# ===========================================================================
# Camada de orquestração
# ===========================================================================

def _carregar_historico() -> List[Concurso]:
    """
    Lê os concursos da base de dados e devolve List[Concurso].
    Garante que NUNCA chegam tuplas brutas ao motor.

    Raises:
        SystemExit: se a DB estiver vazia ou inacessível.
    """
    try:
        concursos: List[Concurso] = carregar_concursos()
    except Exception as exc:
        print(f"[ERRO CRÍTICO] Falha ao aceder à base de dados: {exc}", file=sys.stderr)
        sys.exit(1)

    if not concursos:
        print(
            "[AVISO] A base de dados não contém concursos. "
            "Importe os dados históricos antes de executar o motor.",
            file=sys.stderr,
        )
        sys.exit(1)

    return concursos


def _executar_motor(
    concursos: List[Concurso],
    quantidade: int = QUANTIDADE_JOGOS,
) -> Tuple[List[Tuple[Concurso, float, int]], Dict[str, Any]]:
    """
    Instancia o motor e chama gerar_jogos() com os argumentos corretos.

    O motor espera List[Concurso] — já garantido por _carregar_historico().

    Returns:
        Tupla (jogos, ciclo_info) conforme assinatura oficial do motor:
        Tuple[List[Tuple[Concurso, float, int]], Dict[str, Any]]

    Raises:
        SystemExit: em caso de falha no motor.
    """
    try:
        engine = ProbabilisticEngine()

        # ── Retorno duplo desempacotado explicitamente ────────────────────
        jogos: List[Tuple[Concurso, float, int]]
        ciclo_info: Dict[str, Any]
        jogos, ciclo_info = engine.gerar_jogos(
            concursos=concursos,
            quantidade=quantidade,
        )
        # ──────────────────────────────────────────────────────────────────

    except Exception as exc:
        print(f"[ERRO CRÍTICO] Falha no motor probabilístico: {exc}", file=sys.stderr)
        sys.exit(1)

    return jogos, ciclo_info


def _enriquecer_ciclo_info(
    ciclo_info: Dict[str, Any],
    engine: "ProbabilisticEngine",
    concursos: List[Concurso],
) -> Dict[str, Any]:
    """
    Garante que 'dezenas_faltantes' está presente em ciclo_info.
    Se o motor não o incluiu, chama identificar_dezenas_faltantes() diretamente.
    """
    if "dezenas_faltantes" not in ciclo_info:
        try:
            faltantes = engine.identificar_dezenas_faltantes(concursos)
            ciclo_info["dezenas_faltantes"] = len(faltantes)
        except Exception:
            ciclo_info["dezenas_faltantes"] = 99   # fallback: desativa a janela
    return ciclo_info


# ===========================================================================
# Entrypoint
# ===========================================================================

def main() -> None:
    print("  Iniciando Lotofácil Pro V11...\n")

    # 1. Histórico — List[Concurso] garantido, sem tuplas brutas
    concursos: List[Concurso] = _carregar_historico()
    print(
        f"  ✔  {len(concursos)} concurso(s) carregado(s). "
        f"Último: #{concursos[-1].numero} ({concursos[-1].data})\n"
    )

    # 2. Motor — retorno duplo desempacotado
    engine = ProbabilisticEngine()

    jogos: List[Tuple[Concurso, float, int]]
    ciclo_info: Dict[str, Any]

    try:
        jogos, ciclo_info = engine.gerar_jogos(
            concursos=concursos,
            quantidade=QUANTIDADE_JOGOS,
        )
    except Exception as exc:
        print(f"[ERRO CRÍTICO] Falha no motor probabilístico: {exc}", file=sys.stderr)
        sys.exit(1)

    # 3. Enriquecimento do ciclo_info com dezenas_faltantes (se necessário)
    ciclo_info = _enriquecer_ciclo_info(ciclo_info, engine, concursos)

    # 4. Dashboard — sem risco de AttributeError
    _exibir_dashboard(jogos, ciclo_info)


if __name__ == "__main__":
    main()
