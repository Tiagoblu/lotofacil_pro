# core/infrastructure/database/database.py

import sqlite3
from pathlib import Path
from typing import List, Optional

from core.domain.models import Concurso

# ---------------------------------------------------------------------------
# Configuração do caminho padrão da base de dados
# Ajuste DB_PATH se o seu .db estiver noutro local.
# ---------------------------------------------------------------------------
DB_PATH: Path = Path(__file__).resolve().parents[4] / "lotofacil.db"


# ---------------------------------------------------------------------------
# Helpers de conexão
# ---------------------------------------------------------------------------

def _get_connection(db_path: Path) -> sqlite3.Connection:
    """Cria e devolve uma conexão SQLite com row_factory configurado."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row          # permite acesso por nome de coluna
    conn.execute("PRAGMA journal_mode=WAL") # melhor performance em leitura
    return conn


# ---------------------------------------------------------------------------
# Conversão de tupla bruta → modelo de domínio
# ---------------------------------------------------------------------------

def _row_to_concurso(row: sqlite3.Row) -> Concurso:
    """
    Converte uma linha do SQLite num objeto Concurso do domínio.

    Formato esperado da coluna 'dezenas':
        "01 05 07 09 11 12 13 14 16 18 20 21 22 24 25"
        (inteiros separados por espaço; zeros à esquerda são aceites)
    """
    dezenas_raw: str = row["dezenas"]
    dezenas: tuple[int, ...] = tuple(int(d) for d in dezenas_raw.split())

    return Concurso(
        numero=int(row["numero"]),
        data=str(row["data"]),
        dezenas=dezenas,
    )


# ---------------------------------------------------------------------------
# DDL — inicialização do esquema
# ---------------------------------------------------------------------------

def inicializar_banco(db_path: Path = DB_PATH) -> None:
    """
    Cria a tabela 'concursos' caso ainda não exista.
    Seguro para chamar múltiplas vezes (idempotente).
    """
    ddl = """
        CREATE TABLE IF NOT EXISTS concursos (
            numero  INTEGER PRIMARY KEY,
            data    TEXT    NOT NULL,
            dezenas TEXT    NOT NULL
            -- formato: "01 05 07 ... 25"  (15 inteiros separados por espaço)
        );
    """
    with _get_connection(db_path) as conn:
        conn.execute(ddl)
        conn.commit()


# ---------------------------------------------------------------------------
# Queries de leitura — devolvem SEMPRE List[Concurso], nunca tuplas brutas
# ---------------------------------------------------------------------------

def carregar_concursos(
    db_path: Path = DB_PATH,
    limite: Optional[int] = None,
    offset: int = 0,
) -> List[Concurso]:
    """
    Carrega todos os concursos da base de dados, ordenados por número.

    Args:
        db_path: Caminho para o ficheiro .db.
        limite:  Número máximo de registos a devolver (None = todos).
        offset:  Número de registos a saltar (paginação).

    Returns:
        List[Concurso] — lista de modelos de domínio, nunca tuplas brutas.

    Raises:
        sqlite3.OperationalError: se a tabela não existir ou o ficheiro .db
                                  estiver corrompido.
    """
    query: str = "SELECT numero, data, dezenas FROM concursos ORDER BY numero ASC"
    params: tuple[int, ...] = ()

    if limite is not None:
        query += " LIMIT ? OFFSET ?"
        params = (limite, offset)

    with _get_connection(db_path) as conn:
        cursor = conn.execute(query, params)
        rows = cursor.fetchall()

    return [_row_to_concurso(row) for row in rows]


def carregar_concurso_por_numero(
    numero: int,
    db_path: Path = DB_PATH,
) -> Optional[Concurso]:
    """
    Carrega um concurso específico pelo seu número.

    Returns:
        Concurso se encontrado, None caso contrário.
    """
    query = "SELECT numero, data, dezenas FROM concursos WHERE numero = ? LIMIT 1"
    with _get_connection(db_path) as conn:
        cursor = conn.execute(query, (numero,))
        row = cursor.fetchone()

    return _row_to_concurso(row) if row is not None else None


def carregar_ultimos_concursos(
    n: int,
    db_path: Path = DB_PATH,
) -> List[Concurso]:
    """
    Carrega os N concursos mais recentes (pelo número de concurso).

    Returns:
        List[Concurso] ordenada do mais antigo para o mais recente.
    """
    query = """
        SELECT numero, data, dezenas
        FROM concursos
        ORDER BY numero DESC
        LIMIT ?
    """
    with _get_connection(db_path) as conn:
        cursor = conn.execute(query, (n,))
        rows = cursor.fetchall()

    # Inverte para manter ordem cronológica crescente
    return [_row_to_concurso(row) for row in reversed(rows)]


# ---------------------------------------------------------------------------
# Escrita — inserção de concursos
# ---------------------------------------------------------------------------

def inserir_concurso(concurso: Concurso, db_path: Path = DB_PATH) -> None:
    """
    Persiste um objeto Concurso na base de dados.
    Usa INSERT OR IGNORE para evitar duplicados.
    """
    dezenas_str: str = " ".join(f"{d:02d}" for d in concurso.dezenas)
    query = "INSERT OR IGNORE INTO concursos (numero, data, dezenas) VALUES (?, ?, ?)"
    with _get_connection(db_path) as conn:
        conn.execute(query, (concurso.numero, concurso.data, dezenas_str))
        conn.commit()


def inserir_concursos_em_lote(
    concursos: List[Concurso],
    db_path: Path = DB_PATH,
) -> int:
    """
    Persiste uma lista de Concursos em bloco (executemany).

    Returns:
        Número de linhas efetivamente inseridas.
    """
    dados = [
        (c.numero, c.data, " ".join(f"{d:02d}" for d in c.dezenas))
        for c in concursos
    ]
    query = "INSERT OR IGNORE INTO concursos (numero, data, dezenas) VALUES (?, ?, ?)"
    with _get_connection(db_path) as conn:
        cursor = conn.executemany(query, dados)
        conn.commit()
        return cursor.rowcount
